package com.ridesharingplatform.service;

import java.util.List;



import com.ridesharingplatform.model.IncidentTypes;


public interface IncidentTypesService {

	IncidentTypes createIncidentTypes(IncidentTypes incidentTypes);
	List<IncidentTypes>getAllTypes();
	void deleteIncidentType(int incidentTypeId);
}
