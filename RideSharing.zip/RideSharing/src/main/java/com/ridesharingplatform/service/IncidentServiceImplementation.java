package com.ridesharingplatform.service;


import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.ridesharingplatform.dto.BookingDTO;
import com.ridesharingplatform.exception.CannotReportIncidentException;
import com.ridesharingplatform.exception.DuplicateIncidentException;
import com.ridesharingplatform.model.Incident;
import com.ridesharingplatform.model.IncidentTypes;
import com.ridesharingplatform.repository.IncidentRepository;

@Service
public class IncidentServiceImplementation implements IncidentService{
	
	@Autowired
	private IncidentRepository incidentRepository;
	
	@Autowired
	private RestTemplate restTemplate;

	@Override
	public Incident createIncident(Incident incident) {
		// TODO Auto-generated method stub
		if (incident.getIncidentDate() == null) {
	        throw new IllegalArgumentException("Incident date cannot be null");
	    }
		
		String incidentId = generateIncidentId(incident.getIncidentDate());
        incident.setIncidentId(incidentId);
        

        long diffInMillies = Math.abs(incident.getReportDate().getTime() - incident.getIncidentDate().getTime());
        long diff = TimeUnit.DAYS.convert(diffInMillies,TimeUnit.MILLISECONDS);

        if (diff > 20) {
            throw new CannotReportIncidentException("Cannot report incident more than 2 days after the actual incident");
        }

        // Check if booking ID already has an incident
        int incidentCount = incidentRepository.getIncidentCountByBookingId(incident.getBookingId());

        if (incidentCount > 0) {
            throw new DuplicateIncidentException("Cannot file multiple incidents for the same booking");
        }
		
		IncidentTypes incidentTypes=new IncidentTypes();
		Date resolutionETA = new Date(incident.getIncidentDate().getTime() + incidentTypes.getExpectedSLAInDays() * 24 * 60 * 60 * 1000);
        incident.setResolutionETA(resolutionETA);
		return incidentRepository.save(incident);
	}
	
	  private String generateIncidentId(Date incidentDate) {
		  
		  Calendar calendar = Calendar.getInstance();
		  
		  calendar.setTime(incidentDate);
		  int year = calendar.get(Calendar.YEAR);
		  String yearString = String.valueOf(year); // Get the last two digits of the year

		    // Generate a unique 4-digit number
		    String uniqueNumber = String.format("%04d", incidentRepository.findAll().size() + 1);

		    return yearString + "-" + uniqueNumber;
	    }

	@Override
	public Optional<Incident> getIncidentById(String incidentId) {
		// TODO Auto-generated method stub
//		
		Optional<Incident> incident = incidentRepository.findById(incidentId);
		BookingDTO boi = restTemplate.getForObject("http://localhost:8090/api/getBooking/"+incident.get().getBookingId(),BookingDTO.class);
		System.out.println(boi);
		System.out.println(boi.getBookingId());
		
		return incident;
//		return incidentRepository.findById(incidentId);
	
	}

	@Override
	public Incident updateDetails(String incidentId, Incident incident) {
		// TODO Auto-generated method stub
		Optional<Incident>oldIncidentOptional=incidentRepository.findById(incidentId);
		
		if(oldIncidentOptional.isPresent())
		{
			Incident newIncident=oldIncidentOptional.get();
			
			
			newIncident.setStatus(incident.getStatus());
			
			
			return incidentRepository.save(newIncident);
		}
		else {
			return null;	
		}
		
	}

	@Override
	public List<Incident> getPendingIncident(Incident incident) {
		// TODO Auto-generated method stub
		return incidentRepository.getPendingIncident("pending");
	}

	@Override
	public List<Incident> getData(Incident incident) {
		// TODO Auto-generated method stub
		return incidentRepository.findAll();
	}

	@Override
	public void deleteIncident(String incidentId) {
		// TODO Auto-generated method stub
		incidentRepository.deleteById(incidentId);	
	}
}
