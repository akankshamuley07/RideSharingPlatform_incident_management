package com.ridesharingplatform.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ridesharingplatform.model.Incident;
import com.ridesharingplatform.model.InvestigationDetails;
import com.ridesharingplatform.repository.IncidentRepository;
import com.ridesharingplatform.repository.InvestigationDetailsRepository;

@Service
public class InvestigationServiceImp implements InvestigationService{

	@Autowired
	private InvestigationDetailsRepository investigationDetailsRepository;
	
	@Autowired
	private IncidentRepository incidentRepository;
	
	@Override
	public List<InvestigationDetails> getDetails(InvestigationDetails investigationDetails) {
		
		return investigationDetailsRepository.findAll();
	}

	@Override
	public void deleteDetails(int investigationId) {
		// TODO Auto-generated method stub
		investigationDetailsRepository.deleteById(investigationId);
		
	}

	@Override
	public InvestigationDetails createInvestigationDetails(InvestigationDetails investigationDetails) {
		// TODO Auto-generated method stub
		return investigationDetailsRepository.save(investigationDetails);
	}

	@Override
	public Optional<InvestigationDetails> findInvestigationDetailsByIncidentId(String incidentId) {
		return investigationDetailsRepository.findInvestigationDetailsByIncidentId(incidentId);
		
		// TODO Auto-generated method stub
		
	}

	@Override
	public InvestigationDetails updateInvestigationDetails(String incidentId, InvestigationDetails investigationDetails) {
		// TODO Auto-generated method stub
		Optional<Incident> incident = incidentRepository.findById(investigationDetails.getIncident().getIncidentId());
		if(incident.isPresent()) {
			InvestigationDetails investigationDetails2 = new InvestigationDetails();
			investigationDetails2.setFindings(investigationDetails.getFindings());
			investigationDetails2.setSuggestion(investigationDetails.getSuggestion());
			investigationDetails2.setInvestigationDate(investigationDetails.getInvestigationDate());
			investigationDetails2.setIncident(incident.get());
			return investigationDetailsRepository.save(investigationDetails2);
		}
		else {
			return null;
		}
		
	}
	

}
