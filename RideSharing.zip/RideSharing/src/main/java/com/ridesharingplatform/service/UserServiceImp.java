package com.ridesharingplatform.service;

import java.util.Set;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ridesharingplatform.model.User;
import com.ridesharingplatform.model.UserRole;
import com.ridesharingplatform.repository.RoleRepository;
import com.ridesharingplatform.repository.UserRpository;

@Service
public class UserServiceImp implements UserService {

	@Autowired
	private UserRpository userRpository;
	
	@Autowired 
	private RoleRepository roleRepository;
	
	@Override
	public User createUser(User user,Set<UserRole> userRole) throws Exception {
		
		User localUser=userRpository.findByUsername(user.getUsername());
		
		if(localUser!= null)
		{
			System.out.println("User Already Exist!!!");
			throw new Exception("User Already Exist!!!");
		}else {
			for(UserRole ur:userRole)
			{
				roleRepository.save(ur.getRole());
			}
			
			user.getUserRole().addAll(userRole);
			
			localUser=this.userRpository.save(user);
		}
		
		
		return localUser;
	}
	
	
	

}
