package com.ridesharingplatform.service;


import java.util.List;
import java.util.Optional;

import com.ridesharingplatform.model.Incident;


public interface IncidentService {
	
	
	Incident createIncident (Incident incident);
	Optional<Incident>getIncidentById(String incidentId);
	Incident updateDetails(String incidentId,Incident incident);
	List<Incident>getData(Incident incident);
	List<Incident> getPendingIncident(Incident incident);
	void deleteIncident(String incidentId);
	
	
	

}
