package com.ridesharingplatform.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ridesharingplatform.model.IncidentTypes;
import com.ridesharingplatform.repository.IncidentTypesRepository;

@Service
public class IncidentTypesServiceImp implements IncidentTypesService{

	@Autowired
	private IncidentTypesRepository incidentTypesRepository;
	
	@Override
	public List<IncidentTypes> getAllTypes() {
		return incidentTypesRepository.findAll();
	}

	@Override
	public void deleteIncidentType(int incidentTypeId) {
		// TODO Auto-generated method stub
		incidentTypesRepository.deleteById(incidentTypeId);
		
	}

	@Override
	public IncidentTypes createIncidentTypes(IncidentTypes incidentTypes) {
		// TODO Auto-generated method stub
		return incidentTypesRepository.save(incidentTypes);
		
	}
	

}
