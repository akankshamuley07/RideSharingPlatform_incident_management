package com.ridesharingplatform.service;

import java.util.List;
import java.util.Optional;


import com.ridesharingplatform.model.InvestigationDetails;

public interface InvestigationService {
	
	InvestigationDetails createInvestigationDetails(InvestigationDetails investigationDetails);
	List<InvestigationDetails>getDetails(InvestigationDetails investigationDetails);
	void deleteDetails(int investigationId);
	Optional<InvestigationDetails>findInvestigationDetailsByIncidentId(String incidentId);
	InvestigationDetails updateInvestigationDetails(String incidentId,InvestigationDetails investigationDetails);
}
