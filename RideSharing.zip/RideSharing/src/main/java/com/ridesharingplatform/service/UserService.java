package com.ridesharingplatform.service;


import java.util.Set;

import com.ridesharingplatform.model.User;
import com.ridesharingplatform.model.UserRole;

public interface UserService {
	
	User createUser(User user, Set<UserRole>userRole) throws Exception;

}
