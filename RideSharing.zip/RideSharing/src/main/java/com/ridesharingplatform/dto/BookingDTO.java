package com.ridesharingplatform.dto;

public class BookingDTO {
	
	private int bookingId;
	private int bookedOn;
	private int noOfSeats;
	private int totalAmount;
	private String paymentMode;
	private int riderUserId;
	public int getBookingId() {
		return bookingId;
	}
	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}
	public int getBookedOn() {
		return bookedOn;
	}
	public void setBookedOn(int bookedOn) {
		this.bookedOn = bookedOn;
	}
	public int getNoOfSeats() {
		return noOfSeats;
	}
	public void setNoOfSeats(int noOfSeats) {
		this.noOfSeats = noOfSeats;
	}
	public int getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(int totalAmount) {
		this.totalAmount = totalAmount;
	}
	public String getPaymentMode() {
		return paymentMode;
	}
	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}
	public int getRiderUserId() {
		return riderUserId;
	}
	public void setRiderUserId(int riderUserId) {
		this.riderUserId = riderUserId;
	}
	public BookingDTO(int bookingId, int bookedOn, int noOfSeats, int totalAmount, String paymentMode,
			int riderUserId) {
		super();
		this.bookingId = bookingId;
		this.bookedOn = bookedOn;
		this.noOfSeats = noOfSeats;
		this.totalAmount = totalAmount;
		this.paymentMode = paymentMode;
		this.riderUserId = riderUserId;
	}
	@Override
	public String toString() {
		return "BookingDTO {"+
					"bookingId=" + bookingId +
					", bookedOn=" + bookedOn +
					", noOfSeats=" + noOfSeats +
					", totalAmount=" + totalAmount + 
					", paymentMode=" + paymentMode + 
					", riderUserId=" + riderUserId + "}";
	}
	public BookingDTO() {
		super();
	}
	
	

}
