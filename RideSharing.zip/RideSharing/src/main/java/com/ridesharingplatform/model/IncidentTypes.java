package com.ridesharingplatform.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class IncidentTypes {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private int incidentTypeId;
	private String incidentType;
	private int expectedSLAInDays;
	
	public int getIncidentTypeId() {
		return incidentTypeId;
	}
	public void setIncidentTypeId(int incidentTypeId) {
		this.incidentTypeId = incidentTypeId;
	}
	public String getIncidentType() {
		return incidentType;
	}
	public void setIncidentType(String incidentType) {
		this.incidentType = incidentType;
	}
	public int getExpectedSLAInDays() {
		return expectedSLAInDays;
	}
	public void setExpectedSLAInDays(int expectedSLAInDays) {
		this.expectedSLAInDays = expectedSLAInDays;
	}
	public IncidentTypes(int incidentTypeId, String incidentType, int expectedSLAInDays) {
		super();
		this.incidentTypeId = incidentTypeId;
		this.incidentType = incidentType;
		this.expectedSLAInDays = expectedSLAInDays;
	}
	public IncidentTypes() {
		super();
	}
	
	
	

}
