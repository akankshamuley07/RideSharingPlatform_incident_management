package com.ridesharingplatform.model;

import java.util.Date;


import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class Incident {
	
	@Id
	
	private String incidentId;
	private Date incidentDate;
	private Date reportDate;
	private int incidentReportedByUserId;
	
	@ManyToOne
	@JoinColumn(referencedColumnName = "incidentTypeId")
	private IncidentTypes incidentTypes;
	
	private Date resolutionETA;
	private int investigatedByUserId;
	private String incidentSummary;
	private String incidentDetails;
	private int bookingId;
	private String status;
	public String getIncidentId() {
		return incidentId;
	}
	public void setIncidentId(String incidentId) {
		this.incidentId = incidentId;
	}
	public Date getIncidentDate() {
		return incidentDate;
	}
	public void setIncidentDate(Date incidentDate) {
		this.incidentDate = incidentDate;
	}
	public Date getReportDate() {
		return reportDate;
	}
	public void setReportDate(Date reportDate) {
		this.reportDate = reportDate;
	}
	public int getIncidentReportedByUserId() {
		return incidentReportedByUserId;
	}
	public void setIncidentReportedByUserId(int incidentReportedByUserId) {
		this.incidentReportedByUserId = incidentReportedByUserId;
	}
	public IncidentTypes getIncidentTypes() {
		return incidentTypes;
	}
	public void setIncidentTypes(IncidentTypes incidentTypes) {
		this.incidentTypes = incidentTypes;
	}
	public Date getResolutionETA() {
		return resolutionETA;
	}
	public void setResolutionETA(Date resolutionETA) {
		this.resolutionETA = resolutionETA;
	}
	public int getInvestigatedByUserId() {
		return investigatedByUserId;
	}
	public void setInvestigatedByUserId(int investigatedByUserId) {
		this.investigatedByUserId = investigatedByUserId;
	}
	public String getIncidentSummary() {
		return incidentSummary;
	}
	public void setIncidentSummary(String incidentSummary) {
		this.incidentSummary = incidentSummary;
	}
	public String getIncidentDetails() {
		return incidentDetails;
	}
	public void setIncidentDetails(String incidentDetails) {
		this.incidentDetails = incidentDetails;
	}
	public int getBookingId() {
		return bookingId;
	}
	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Incident(String incidentId, Date incidentDate, Date reportDate, int incidentReportedByUserId,
			IncidentTypes incidentTypes, Date resolutionETA, int investigatedByUserId, String incidentSummary,
			String incidentDetails, int bookingId, String status) {
		super();
		this.incidentId = incidentId;
		this.incidentDate = incidentDate;
		this.reportDate = reportDate;
		this.incidentReportedByUserId = incidentReportedByUserId;
		this.incidentTypes = incidentTypes;
		this.resolutionETA = resolutionETA;
		this.investigatedByUserId = investigatedByUserId;
		this.incidentSummary = incidentSummary;
		this.incidentDetails = incidentDetails;
		this.bookingId = bookingId;
		this.status = status;
	}
	public Incident() {
		super();
	}
	
	
	

}
