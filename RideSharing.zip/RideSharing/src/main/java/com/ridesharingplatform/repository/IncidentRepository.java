package com.ridesharingplatform.repository;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.ridesharingplatform.model.Incident;

@Repository
public interface IncidentRepository extends JpaRepository<Incident,String> {
	
//	 @Query("SELECT i FROM Incident i JOIN i.incidentType it WHERE i.status = 'pending' ORDER BY it.name, i.incidentDate")
//	  public List<Incident> findPendingIncidentsSortedByTypeAndDate() {
//	    return entityManager.createQuery(query).getResultList();
//	  }
	
	@Query(value = "select i from Incident i join i.incidentTypes it where i.status= :val ORDER BY i.incidentDate,it.incidentType asc")
	public List<Incident> getPendingIncident(@Param ("val") String status);
	
	




    @Query("SELECT COUNT(i) FROM Incident i WHERE i.bookingId = :bookingId")
   int getIncidentCountByBookingId(@Param("bookingId") int bookingId);

}
