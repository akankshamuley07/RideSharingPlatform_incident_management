package com.ridesharingplatform.exception;

public class DuplicateIncidentException extends RuntimeException {
	
	private static final long serialVersionUID = 1L;
	public DuplicateIncidentException(String msg)
	{
		super(msg);
		
	}

}
