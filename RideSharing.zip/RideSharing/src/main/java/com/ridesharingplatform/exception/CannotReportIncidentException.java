package com.ridesharingplatform.exception;

public class CannotReportIncidentException extends RuntimeException{
	
	private static final long serialVersionUID = 1L;
	public CannotReportIncidentException(String msg)
	{
		super(msg);
		
	}

}
