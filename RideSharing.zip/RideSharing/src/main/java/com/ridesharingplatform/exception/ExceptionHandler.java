package com.ridesharingplatform.exception;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RestController;




@RestController
@CrossOrigin
@ControllerAdvice
public class ExceptionHandler {
	
	Logger logger=LoggerFactory.getLogger(ExceptionHandler.class);
	
	@org.springframework.web.bind.annotation.ExceptionHandler(CannotReportIncidentException.class)
	public ResponseEntity<APIError>HandleCannotReportIncident()
	{
		APIError error=new APIError(400,"Cannot report incident more than 2 days after the actual incident");
		return new ResponseEntity<>(error,HttpStatus.BAD_REQUEST); 
	}

	@org.springframework.web.bind.annotation.ExceptionHandler(DuplicateIncidentException.class)
	public ResponseEntity<APIError>HandleDuplicateIncident()
	{
		APIError error1=new APIError(208, "Cannot file multiple incidents for the same booking");
		return new ResponseEntity<>(error1,HttpStatus.ALREADY_REPORTED);
	}
}
