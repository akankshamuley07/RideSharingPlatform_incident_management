package com.ridesharingplatform.controller;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.ridesharingplatform.model.InvestigationDetails;


import com.ridesharingplatform.service.InvestigationService;

@RestController
@CrossOrigin
@RequestMapping("/investigationDetails")
public class InvestigationDetailsController {
	
	
	@Autowired
	private InvestigationService investigationService;
	
	Logger logger=LoggerFactory.getLogger(InvestigationDetailsController.class);
	
	@GetMapping("/hello2")
	public String hello() {
		return "hello";
	}
	@GetMapping("/{incidentId}")
	public ResponseEntity<InvestigationDetails>getIncidentById(@PathVariable String incidentId)
	{
		logger.trace("Investigation details for related incident id");
		Optional<InvestigationDetails>incident=investigationService.findInvestigationDetailsByIncidentId(incidentId);
		return incident.map(Value -> new ResponseEntity<>(Value, HttpStatus.OK))
				.orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
				
				
	}
	@PutMapping("/updateInvestigationDetails/{incidentId}")
	public ResponseEntity<InvestigationDetails>updateInvestigationDetails(@PathVariable String incidentId ,@RequestBody InvestigationDetails investigationDetails)
	{
		InvestigationDetails updatedDetails=investigationService.updateInvestigationDetails(incidentId, investigationDetails);
		if(updatedDetails!=null)
		{	
			logger.trace("Details updated");
			return new ResponseEntity<InvestigationDetails>(updatedDetails,HttpStatus.OK);
		}else {
			logger.error("given incidentid doesn't match with existing incidentid");
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}

	@PostMapping("/createinvestigation")
	public ResponseEntity<InvestigationDetails> saveInvestigationDetails(@RequestBody InvestigationDetails investigationDetails) {
		 logger.trace("Added investigation details");
		InvestigationDetails investigationDetails2=investigationService.createInvestigationDetails(investigationDetails);
		return new ResponseEntity<>(investigationDetails2,HttpStatus.CREATED);
	}
	
	@GetMapping("/investigationDetails")
	public ResponseEntity<List<InvestigationDetails>>getInvestigationDetails(InvestigationDetails investigationDetails)
	{
		logger.trace("Fetched all investigation details");
		List<InvestigationDetails> details=investigationService.getDetails(investigationDetails);
		return new ResponseEntity<>(details,HttpStatus.OK);
	}
	
	@DeleteMapping("/deleteInvestigationDetails/{investigationId}")
	public ResponseEntity<Void>deleteInvestigation(@PathVariable int investigationId)
	{
		logger.trace("Record deleted");
		investigationService.deleteDetails(investigationId);
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}
	
	

}
