package com.ridesharingplatform.controller;


import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ridesharingplatform.model.IncidentTypes;

import com.ridesharingplatform.service.IncidentTypesService;



@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/incidents")
public class IncidentTypesController {
	
	Logger logger =LoggerFactory.getLogger(IncidentTypesController.class);
	
	@Autowired
	private IncidentTypesService incidentTypesService;
	
	@GetMapping("/types")
	public ResponseEntity<List<IncidentTypes>>getAllTypes()
	{
		logger.trace("Fetching list of all incident types");
		List<IncidentTypes> types=incidentTypesService.getAllTypes();
		return new ResponseEntity<>(types,HttpStatus.OK);
		
	}
	
	@GetMapping("/hello")
	public String hello() {
		return "hello";
	}
	
	
	@PostMapping("/create")
	public ResponseEntity<IncidentTypes> createIncidentTypes(@RequestBody IncidentTypes incidentTypes) {
		logger.trace("Incident type inserted");
		IncidentTypes incidentTypes2=incidentTypesService.createIncidentTypes(incidentTypes);
		return new ResponseEntity<>(incidentTypes2,HttpStatus.CREATED); 
	}
	
	@DeleteMapping("/deleteIncidentType/{incidentTypeId}")
	public ResponseEntity<Void>deleteIncidentType(@PathVariable int incidentTypeId)
	{
		logger.trace("Deleted existing detail");
		incidentTypesService.deleteIncidentType(incidentTypeId);
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}

}
