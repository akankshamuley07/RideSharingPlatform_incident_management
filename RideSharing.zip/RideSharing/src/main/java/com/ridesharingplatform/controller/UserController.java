package com.ridesharingplatform.controller;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ridesharingplatform.model.User;
import com.ridesharingplatform.model.UserRole;
import com.ridesharingplatform.service.UserService;


@RestController
@RequestMapping("/user")
public class UserController {
	
	@Autowired
	UserService userService;
	
	
	@PostMapping("/createUser")
	public ResponseEntity<User>  createUser(@RequestBody User user,Set<UserRole> userRole) throws Exception{
		
		User user2 =userService.createUser(user, userRole);
		
		return new ResponseEntity<>(user2,HttpStatus.CREATED); 
	}

}
