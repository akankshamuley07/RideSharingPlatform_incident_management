package com.ridesharingplatform.controller;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ridesharingplatform.model.Incident;
import com.ridesharingplatform.repository.IncidentRepository;
import com.ridesharingplatform.service.IncidentService;

@RestController
@CrossOrigin
@RequestMapping("/incidents")
public class IncidentController {
	
	Logger logger=LoggerFactory.getLogger(IncidentController.class);
	
	@Autowired
	private IncidentService incidentService;
	
	@Autowired
	private IncidentRepository incidentRepository;
	
	
	@GetMapping("/hello1")
	public String hello() {
		return "hello";
	}
	
	
	@PostMapping("/report")
	public ResponseEntity<Incident> createIncident(@RequestBody Incident incident) {
		logger.trace("Incident reported");
		Incident createdIncident=incidentService.createIncident(incident);
		return new ResponseEntity<Incident>(createdIncident,HttpStatus.CREATED);
	}
	
	@GetMapping("/{incidentId}")
	public ResponseEntity<Incident>getIncidentById(@PathVariable String incidentId)
	{
		logger.trace("Incident details for related incident id");
		Optional<Incident>incident=incidentService.getIncidentById(incidentId);
		return incident.map(Value -> new ResponseEntity<>(Value, HttpStatus.OK))
				.orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
	
	}
	
	@GetMapping("/getbyId/{incidentId}")
	public ResponseEntity<Incident>getParticularId(@PathVariable String incidentId)
	{
		Optional<Incident>incident=incidentRepository.findById(incidentId);
		return incident.map(Value-> new ResponseEntity<>(Value,HttpStatus.OK))
				.orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
		
	}
	
	@PutMapping("/investigationreport/{incidentId}")
	public ResponseEntity<Incident>updateDetails(@PathVariable String incidentId, @RequestBody Incident incident)
	{
		Incident updatedDetails=incidentService.updateDetails(incidentId, incident);
		if(updatedDetails!=null)
		{	
			logger.trace("Details updated");
			return new ResponseEntity<Incident>(updatedDetails,HttpStatus.OK);
		}else {
			logger.error("given incidentid doesn't match with existing incidentid");
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
		
	}
	
	@GetMapping("/data")
	public ResponseEntity<List<Incident>>getData(Incident incident)
	{
		
		List<Incident> dataIncidents=incidentService.getData(incident);
		return new ResponseEntity<>(dataIncidents,HttpStatus.OK);
		
	}
	
	@GetMapping()
	public ResponseEntity<List<Incident>>getPendingIncident(Incident incident)
	{
		logger.trace("Fetching all pending incidents.");
		List<Incident> pending=incidentService.getPendingIncident(incident);
		return new ResponseEntity<>(pending,HttpStatus.OK);	
	}
	
	@DeleteMapping("/delete/{incidentId}")
	public ResponseEntity<Void> deleteById(@PathVariable String incidentId)
	{
		logger.trace("Deleting record.");
		incidentService.deleteIncident(incidentId);
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		
		
	}
	
	

}
