package com.ridesharingplatform;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;

import static org.mockito.Mockito.when;

import java.util.Date;
import java.util.List;
import java.util.Optional;


import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;


import com.ridesharingplatform.exception.DuplicateIncidentException;
import com.ridesharingplatform.model.Incident;
import com.ridesharingplatform.model.IncidentTypes;
import com.ridesharingplatform.repository.IncidentRepository;
import com.ridesharingplatform.repository.IncidentTypesRepository;
import com.ridesharingplatform.service.IncidentService;
import com.ridesharingplatform.service.IncidentTypesService;


@RunWith(SpringRunner.class)
@SpringBootTest
public class RideSharingApplicationTests {
	
	@Autowired
	private IncidentTypesService service;
	
	@MockBean
	private IncidentTypesRepository repository;
	
	@Test
	public void getAllTypesTest()
	{
		IncidentTypes incidentTypes=new IncidentTypes(1,"Accident",3);
		IncidentTypes incidentTypes1=new IncidentTypes(1,"Theft",2);
		when(repository.findAll()).thenReturn(List.of(incidentTypes,incidentTypes1));
		
		List<IncidentTypes> result= service.getAllTypes();
		assertEquals(2, result.size());
	}
	
	@Autowired
	private IncidentService incidentService;
	
	@MockBean
	private IncidentRepository incidentRepository;
	
	

	@Test
	public void createTest()
	{
		IncidentTypes incidentTypes=new IncidentTypes(1,"Accident",5);
		
		Incident incident = new Incident(null, null, null, 0, null, null, 0, null, null, 1, null);
		Incident incident2 = new Incident("2024-0039",new Date (), new Date(),12,incidentTypes, new Date(), 13, null, null, 1, "pending");
		when(incidentRepository.save(incident)).thenReturn(incident);
		when(incidentRepository.getIncidentCountByBookingId(incident2.getBookingId())).thenReturn(1);
		assertThrows(DuplicateIncidentException.class, ()->incidentService.createIncident(incident2));

	}
	
	@Test
	public void getPendingTest() {
		//Incident incident = new Incident();
		Incident incident2 = new Incident(null,null, null, 0,null, null, 0, null, null, 0, "pending");
		when(incidentRepository.getPendingIncident("pending")).thenReturn(List.of(incident2));
		List<Incident> incidents =incidentService.getPendingIncident(incident2);
		assertEquals(1,incidents.size());
	}
	
	@Test
	public void updateDetailsTest() {
		String incidentId="book23";
		Incident incident = new Incident("book23", null, null, 0, null, null, 0, null, "theft", 0, null);
		when(incidentRepository.findById(incidentId)).thenReturn(Optional.of(incident));
		when(incidentRepository.save(any(Incident.class))).thenReturn(incident);
		Incident incident2 = incidentService.updateDetails(incidentId, incident);
		assertEquals("theft", incident2.getIncidentDetails());
		}

}
